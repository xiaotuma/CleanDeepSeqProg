#The code associated with this package are intended free-of-charge for non-profit usages. 
#Please contact the author for for-profit usages, modifications and re-distributions. 
#Please contact the author Xiaotu Ma at Xiaotu.Ma@stjude.org for questions, bugs.


use strict;
use warnings;
use POSIX;
use Data::Dumper;

sub qscore {  my $letter=shift; return(ord($letter)-33); }

sub filter_sam {
  my $ifn  = shift;
  my $ofn  = shift;
  my $qcut = shift;
  my $pcnt = shift;
  my $trim = shift;
  my $ifh;
  my $ofh;
  open($ifh, "<$ifn") or die "cannot open ifile $ifn\n";
  open($ofh, ">$ofn") or die "cannot open ifile $ofn\n";
  my $line;
  my $tot=0;
  while($line=<$ifh>) {
    $tot++;
    print $tot, "\n" if($tot%500000==0);
    chomp $line;
    my @eles = split /\t/, $line;
    my $seqid=$eles[0];
    my $flags=$eles[1];
    my $chrom=$eles[2];
    my $posit=$eles[3];
    my $mapqs=$eles[4];
    my $cigar=$eles[5];
    my $rnext=$eles[6];
    my $pnext=$eles[7];
    my $tlens=$eles[8];
    my $seqss=$eles[9];
    my $quass=$eles[10];
    next if(not ($rnext eq "="));
    next if(not($cigar =~ /^\d+M$/));
    next if($mapqs<55 or $mapqs>254);
    my @quals=split //, $quass;
    my @sequs=split //, $seqss;
    my $nBad = 0;
    for(my $i=0;$i<=$#quals;$i++) {
      if(qscore($quals[$i])<$qcut) {
        $nBad++;
      }
    }
    if($nBad<=$pcnt*($#quals+1)) {
      my $npos=$posit+$trim;
      print $ofh "$seqid\t$flags\t$chrom\t$npos\t$mapqs\t$cigar\t$rnext\t$pnext\t$tlens";
      print $ofh "\t",join("",@sequs[$trim .. ($#sequs-$trim)]);
      print $ofh "\t",join("",@quals[$trim .. ($#sequs-$trim)]),"\n";
    }
  }
  close($ifh);
  close($ofh);
}

sub parse_hd {
  my $ifn = shift;
  my $ret = shift;
  my $ifh;
  open($ifh, "<$ifn") or die "cannot open ifile $ifn\n";
  my $line;
  my %chrs;
  for(my $i=1;$i<=22;$i++) {
    my $add = "chr" . $i;
    $chrs{$i} = 1;
    $chrs{$add} = 1; 
  }
  $chrs{"X"} = 1;
  $chrs{"chrX"} = 1;    
  $chrs{"Y"} = 1;
  $chrs{"chrY"} = 1;    
  
  while($line=<$ifh>) {
    chomp $line;
    next if(not $line =~ /\@SQ/);
    next if(not $line =~ /SN:/);
    my @eles=split /\t/, $line;
    my $sn=$eles[1];
    my $ln=$eles[2];
    my @sns=split /:/, $sn;  
    my @lns=split /:/, $ln;
    if(exists $chrs{$sns[1]}) {
      $ret->{$sns[1]} = $lns[1];
    }
  }
  close($ifh);
}

sub linenumbers {
  my $ifn = shift;
  my $ifh;
  open($ifh, "<$ifn") or die "cannot open ifile $ifn\n";
  my $cnt = 0;
  while(<$ifh>) {
    chomp;
    $cnt++ if  !/^\s+$/;
  }
  close($ifh);
  return($cnt);
}

sub parse_bamhd {
  my $ifn=shift;
  my $headerifn=`cat /dev/urandom | tr -dc 'a-z0-9' | head -c 30`;
  my $cmd = "samtools view -H " . $ifn . " > " . $headerifn;
  system($cmd);
  my %chrs;
  my $chrinfo=\%chrs;
  parse_hd($headerifn,$chrinfo);
  unlink $headerifn;
  return($chrinfo);
}

sub count_readpair {
  #seq1, seq2, qua1, qua2 must by array already
  #read1 must be before read2
  #end trim should have been done already
  my $seq1=shift;
  my $qua1=shift;
  my $start1=shift;
  my $seq2=shift;
  my $qua2=shift;
  my $start2=shift;
  my $qcuts=shift;
  my $finalcount=shift;
  my $finalcount_anchorpoint=shift;
  my $pairerr=shift;
  my $dopair=shift;
  my $cutq;
  my $read2pos;
  my %bases;
  $bases{"A"}=1;
  $bases{"C"}=1;
  $bases{"G"}=1;
  $bases{"T"}=1;
  if($start1>$start2) {
    print "start1 must be less than start2\n";
    return 1;
  }
  my $i;
  my $total_scan_len=$#{$seq1};
  if($total_scan_len < $start2 - $start1 + $#{$seq2}) {
    $total_scan_len = $start2 - $start1 + $#{$seq2};
  }
  for($i=0;$i<=$total_scan_len;$i++) {
    my $coord = $i+$start1-$finalcount_anchorpoint;
    if($i<=$#{$seq1}) {      
      if($i<$start2-$start1) {  #not reaching read2 yet    
        foreach $cutq (@{$qcuts}) {
          if(qscore($qua1->[$i])>=$cutq and (exists $bases{$seq1->[$i]})) {
            $finalcount->{$cutq}->{$seq1->[$i]}->[$coord]++;
            $finalcount->{$cutq}->{N}->[$coord]++;
          }
        }
      } else {
        $read2pos=$i-($start2-$start1);
        if($read2pos>=0 and $read2pos<=$#{$seq2}) { #within read2 and read2
          my $base1 = $seq1->[$i];
          my $base2 = $seq2->[$read2pos];
          my $q1    = qscore($qua1->[$i]);
          my $q2    = qscore($qua2->[$read2pos]);
          foreach $cutq (@{$qcuts}) {
            my $useBase="";
            if($q1>=$cutq) {
              $useBase = $base1;
              if($q2>=$cutq) {
                if($base1 ne $base2) {
                  $useBase="";
                }
              }
            } else {
              if($q2>=$cutq) {
                $useBase = $base2;
              }
            }
            if($q1>=$cutq-5 and $q2>=$cutq-5 and $base1 ne $base2) {
              $useBase="";
            }
            if(exists $bases{$useBase}) {
              $finalcount->{$cutq}->{$useBase}->[$coord]++;
              $finalcount->{$cutq}->{N}->[$coord]++;
            }
            if($q1>=$cutq and $q2>$cutq and $dopair==1) {
              $pairerr->{$cutq}->{$base1 . $base2}++;
            }
          }
        }
        else { #out of read2 but still in read1
          foreach $cutq (@{$qcuts}) {
            if(qscore($qua1->[$i])>=$cutq and (exists $bases{$seq1->[$i]})) {
              $finalcount->{$cutq}->{$seq1->[$i]}->[$coord]++;
              $finalcount->{$cutq}->{N}->[$coord]++;
            }
          }
        }
      }
    }
    if($i>$#{$seq1}) { #now outside read1, covered only by read2
      $read2pos=$i-($start2-$start1);
      if($read2pos<=$#{$seq2} and $read2pos>=0) {    
        foreach $cutq (@{$qcuts}) {  
          if(qscore($qua2->[$read2pos])>=$cutq and (exists $bases{$seq2->[$read2pos]})) {
            $finalcount->{$cutq}->{$seq2->[$read2pos]}->[$coord]++;
            $finalcount->{$cutq}->{N}->[$coord]++;
          }
        }
      }
    }  
  }
}

sub fill_read_info {
  my $readinfo=shift;
  my $line=shift;
  if($line ne "") {
    my @eles = split /\t/, $line;
    $readinfo->{names}=$eles[0];
    $readinfo->{flags}=$eles[1];
    $readinfo->{chrom}=$eles[2];
    $readinfo->{start}=$eles[3];
    $readinfo->{mapqs}=$eles[4];
    $readinfo->{cigar}=$eles[5];
    $readinfo->{rnext}=$eles[6];
    $readinfo->{pnext}=$eles[7];
    $readinfo->{segln}=$eles[8];
    $readinfo->{reads}=$eles[9];
    $readinfo->{quals}=$eles[10];
  } else {
    $readinfo->{names}="";
    $readinfo->{flags}="";
    $readinfo->{chrom}="";
    $readinfo->{start}="";
    $readinfo->{mapqs}="";
    $readinfo->{cigar}="";
    $readinfo->{rnext}="";
    $readinfo->{pnext}="";
    $readinfo->{segln}="";
    $readinfo->{reads}="";
    $readinfo->{quals}="";  
  }
}

sub count_sam {
  my $counts = shift;
  my $holderlen = shift;
  my $samifn=shift;
  my $chrom=shift;
  my $mX=shift;
  my $qcuts=shift;
  my $countofn=shift;
  my $outputStart=shift;
  my $outputEnd=shift;
  my $minCvg=shift;
  my $hasHeader=shift;
  my $pairerr=shift;
  my $dopair=shift;
  my %bases;
  $bases{"A"}=1;   
  $bases{"C"}=1;   
  $bases{"G"}=1;   
  $bases{"T"}=1; 
  my $cutq;
  my $minCutq = 10000;
  foreach $cutq (@{$qcuts}) {
    $minCutq=$cutq if($minCutq>$cutq);
    for(my $i=0;$i<$holderlen;$i++) {
      $counts->{$cutq}->{"A"}->[$i]=0;
      $counts->{$cutq}->{"C"}->[$i]=0;
      $counts->{$cutq}->{"G"}->[$i]=0;
      $counts->{$cutq}->{"T"}->[$i]=0;
      $counts->{$cutq}->{"N"}->[$i]=0;
    }
  }
  my $ifh;
  open($ifh, "<$samifn") or die "cannot open ifile $samifn\n";
  my $line;
  my %read1;
  my %read2;
  my $read1info=\%read1;
  my $read2info=\%read2;
  my $curname="";
  while($line=<$ifh>) {
    chomp $line;
    next if(length($line)<2);
    fill_read_info($read2info,$line);
    if($curname eq $read2info->{names}) {
      my @seq1 = split //, $read1info->{reads};
      my @qua1 = split //, $read1info->{quals};
      my $start1 = $read1info->{start};
      my @seq2 = split //, $read2info->{reads};
      my @qua2 = split //, $read2info->{quals};
      my $start2 = $read2info->{start};
      if($#seq1 > 30 and $#seq2 > 30) {
        my $ss1 = \@seq1;
        my $qq1 = \@qua1;
        my $ss2 = \@seq2;
        my $qq2 = \@qua2;
        if(($#seq1 eq $#qua1) and ($#seq2 eq $#qua2)) {
          if($start1<$start2) {
            count_readpair($ss1,$qq1,$start1,$ss2,$qq2,$start2,$qcuts,$counts,$mX,$pairerr,$dopair);
          } else {
            count_readpair($ss2,$qq2,$start2,$ss1,$qq1,$start1,$qcuts,$counts,$mX,$pairerr,$dopair);
          }
        }
      }
      fill_read_info($read1info,"");
      fill_read_info($read2info,"");
      $curname = "";
    } else {
      if(not($curname eq "")) {
        my @seq1 = split //, $read1info->{reads};
        my @qua1 = split //, $read1info->{quals};
        my $start1 = $read1info->{start};
        if($#seq1 > 30) {
          if($#seq1 eq $#qua1) {
            for(my $i=0;$i<=$#seq1;$i++) {
              my $coord = $i + $start1 - $mX;
              foreach $cutq (@{$qcuts}) {  #all qual cuts
                if(qscore($qua1[$i])>=$cutq and (exists $bases{$seq1[$i]})) {
                  $counts->{$cutq}->{$seq1[$i]}->[$coord]++;
                  $counts->{$cutq}->{"N"}->[$coord]++;
                }
              }
            }
          }
        }
      }
      fill_read_info($read1info,$line);
      fill_read_info($read2info,"");
      $curname = $read1info->{names};
    }
  }
  if(not($curname eq "")) {
    my @seq1 = split //, $read1info->{reads};
    my @qua1 = split //, $read1info->{quals};
    my $start1 = $read1info->{start};
    if($#seq1 > 30) {
      if($#seq1 eq $#qua1) {
        for(my $i=0;$i<=$#seq1;$i++) {
          my $coord = $i + $start1 - $mX;
          foreach $cutq (@{$qcuts}) {  #all qual cuts
            if(qscore($qua1[$i])>=$cutq and (exists $bases{$seq1[$i]})) {
              $counts->{$cutq}->{$seq1[$i]}->[$coord]++;
              $counts->{$cutq}->{"N"}->[$coord]++;
            }
          }
        }
      }
    }
  }
  my $ofh;
  my $chrchr = $chrom;
  $chrchr = "chr" . $chrom  if(not $chrom =~ /chr/);
  open($ofh, ">>$countofn") or die "cannot open ofile $countofn\n";
  if($hasHeader==0) {
    print $ofh "Chr.Pos\tPos";
    foreach $cutq (sort @{$qcuts}) {
      print $ofh "\tA_Q_$cutq\tC_Q_$cutq\tG_Q_$cutq\tT_Q_$cutq\tN_Q_$cutq";
    }
    print $ofh "\n";
    $hasHeader=1;
  }
  for(my $i=0;$i<$holderlen;$i++) {
    my $curPos = $i + $mX;
    if($curPos>=$outputStart and $curPos<=$outputEnd) {
      if($counts->{$minCutq}->{"N"}->[$i]>=$minCvg) {
        print $ofh $chrchr, ".", $curPos, "\t", $curPos;
        foreach $cutq (@{$qcuts}) {
          print $ofh "\t", $counts->{$cutq}->{"A"}->[$i],"\t",$counts->{$cutq}->{"C"}->[$i];
          print $ofh "\t", $counts->{$cutq}->{"G"}->[$i],"\t",$counts->{$cutq}->{"T"}->[$i];
          print $ofh "\t", $counts->{$cutq}->{"N"}->[$i];
        }
        print $ofh "\n";
      }
    }
  }
  close($ofh);
  return $hasHeader;
}

sub count_big_bam {
  my $ifn=shift;
  my $ofn=shift;
  my $myqcut=shift;
  my $minCvg=shift;
  my $readqcut=shift;
  my $readfcut=shift;
  my $trimlen=shift;
  my @qcuts=split/,/, $myqcut;
  my $win    = 3000000;
  my $offsetL =   10000;
  my $offsetR =    5000;
  my $holderlen =  $win + 2*$offsetL + 2*$offsetR + 100; 
  my %pairerror;
  my $pairerr=\%pairerror;
  my $jj;
  for($jj=0;$jj<=$#qcuts;$jj++) {
    $pairerr->{$qcuts[$jj]}->{AA}=0;
    $pairerr->{$qcuts[$jj]}->{AC}=0;
    $pairerr->{$qcuts[$jj]}->{AG}=0;
    $pairerr->{$qcuts[$jj]}->{AT}=0;
    $pairerr->{$qcuts[$jj]}->{CA}=0;
    $pairerr->{$qcuts[$jj]}->{CC}=0;
    $pairerr->{$qcuts[$jj]}->{CG}=0;
    $pairerr->{$qcuts[$jj]}->{CT}=0;
    $pairerr->{$qcuts[$jj]}->{GA}=0;
    $pairerr->{$qcuts[$jj]}->{GC}=0;
    $pairerr->{$qcuts[$jj]}->{GG}=0;
    $pairerr->{$qcuts[$jj]}->{GT}=0;
    $pairerr->{$qcuts[$jj]}->{TA}=0;
    $pairerr->{$qcuts[$jj]}->{TC}=0;
    $pairerr->{$qcuts[$jj]}->{TG}=0;
    $pairerr->{$qcuts[$jj]}->{TT}=0;
  }
  my %countss;
  my $minCutq=10000;
  foreach my $cutq (@qcuts) {
    $minCutq=$cutq if($minCutq>$cutq);
    $countss{$cutq}->{"A"}=[];
    $countss{$cutq}->{"C"}=[];
    $countss{$cutq}->{"G"}=[];
    $countss{$cutq}->{"T"}=[];
    $countss{$cutq}->{"N"}=[];
    for(my $i=0;$i<$holderlen;$i++) {
      $countss{$cutq}->{"A"}->[$i]=0;
      $countss{$cutq}->{"C"}->[$i]=0;
      $countss{$cutq}->{"G"}->[$i]=0;
      $countss{$cutq}->{"T"}->[$i]=0;
      $countss{$cutq}->{"N"}->[$i]=0;
    }
  }
  my $counts=\%countss;
  my $chrinfo=parse_bamhd($ifn);
  my $chr;
  my $pos;
  my $after=$ofn;
  unlink $after;
  my $samifn="$ofn.OO";
  my $filteredsamifn="$ofn.FF";
  my $i;
  my $cutqs=\@qcuts;
  my $tot=0;
  my $hasHeaderFiltered=0;
  my $nLenSam=0;
  foreach $chr (sort keys %{$chrinfo}) {
    my $len = $chrinfo->{$chr};
    my $step = ceil($len/($win+0.1));
    for(my $i=1;$i<=$step;$i++) {
      print "Step ",$tot++,"\n";
      my $start = ($i-1)*$win+1;
      my $end   = $i*$win;
      my $softstart = $start - $offsetL;
      my $softend   = $end   + $offsetR;
      $softstart=1 if($softstart<1);
      $softend=$len if($softend>$len);
      my $cmd = "samtools view $ifn $chr:$softstart-$softend | sort -k1,1 > $samifn";
      #print $cmd, "\n";
      system($cmd);
      my $mX = $softstart;
      $nLenSam=linenumbers($samifn);
      if($nLenSam>100) {
        filter_sam($samifn,$filteredsamifn,$readqcut,$readfcut,$trimlen);
        $nLenSam=linenumbers($filteredsamifn);
        if($nLenSam>100) {
          $hasHeaderFiltered=count_sam($counts, $holderlen, $filteredsamifn, $chr, $mX, $cutqs, $after, $start, $end, $minCvg,$hasHeaderFiltered,$pairerr,1);
        }
      }
      unlink $samifn;
      unlink $filteredsamifn;
    }
  }  
  my $ooffnn="$ofn.pairerr";
  unlink $ooffnn;
  my $ooffhh;
  open($ooffhh,">$ooffnn") or die "cannot open ofile $ooffnn\n";
  print $ooffhh "Qcut\tAA\tAC\tAG\tAT\tCA\tCC\tCG\tCT\tGA\tGC\tGG\tGT\tTA\tTC\tTG\tTT\n";
  for($jj=0;$jj<=$#qcuts;$jj++) {
    print $ooffhh $qcuts[$jj],"\t",
                  $pairerr->{$qcuts[$jj]}->{AA},"\t",
                  $pairerr->{$qcuts[$jj]}->{AC},"\t",
                  $pairerr->{$qcuts[$jj]}->{AG},"\t",
                  $pairerr->{$qcuts[$jj]}->{AT},"\t",
                  $pairerr->{$qcuts[$jj]}->{CA},"\t",
                  $pairerr->{$qcuts[$jj]}->{CC},"\t",
                  $pairerr->{$qcuts[$jj]}->{CG},"\t",
                  $pairerr->{$qcuts[$jj]}->{CT},"\t",
                  $pairerr->{$qcuts[$jj]}->{GA},"\t",
                  $pairerr->{$qcuts[$jj]}->{GC},"\t",
                  $pairerr->{$qcuts[$jj]}->{GG},"\t",
                  $pairerr->{$qcuts[$jj]}->{GT},"\t",
                  $pairerr->{$qcuts[$jj]}->{TA},"\t",
                  $pairerr->{$qcuts[$jj]}->{TC},"\t",
                  $pairerr->{$qcuts[$jj]}->{TG},"\t",
                  $pairerr->{$qcuts[$jj]}->{TT},"\n";
  }
  close($ooffhh);
  unlink $ooffhh;
} 

if($#ARGV==6) {
  my $bamifn=$ARGV[0];
  my $ofn=$ARGV[1];
  my $myqcut=$ARGV[2];
  my $minCvg=$ARGV[3];
  my $readqcut=$ARGV[4];
  my $readfcut=$ARGV[5];
  my $trimlen=$ARGV[6];
  count_big_bam($bamifn,$ofn, $myqcut,$minCvg,$readqcut,$readfcut,$trimlen);
} else {
  print "The code associated with this package are intended free-of-charge for non-profit usages. \n";
  print "Please contact the author for for-profit usages, modifications and re-distributions. \n";
  print "Please contact the author Xiaotu Ma at Xiaotu.Ma AT stjude.org for questions, bugs.\n";

  print "Usage: perl ~ <bam.ifn          | absolute path>\n";
  print "              <count.ofn        | absolute path>\n";
  print "              <qcuts            | 0,30,38>\n";
  print "              <min.cvg.4.output | 20>\n";
  print "              <read.q.cut       | 25>\n";
  print "              <read.frac.cut    | 0.04>\n";
  print "              <trimlen          | 10>\n"; 
  print "NEED samtools AND indexed bam\n"; 
}

