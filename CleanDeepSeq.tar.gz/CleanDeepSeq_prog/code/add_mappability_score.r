
args<-commandArgs(trailingOnly=TRUE)
if(length(args)!=3) {
  print("Usage: Rscript ~ <geno.ifn> <mappability.ifn> <ofn>")
}
if(length(args)==3) {
  genoifn<-args[1]
  mappable<-args[2]
  ofn<-args[3]
  geno<-read.table(genoifn, header=TRUE,sep="\t")  
  chr.geno<-as.character(geno[,"Chr"])
  pos.geno<-as.integer(geno[,"Pos"])
  chrsss<-unique(chr.geno)
  mapp<-read.table(mappable,header=TRUE,sep="\t",colClass=c("character","numeric","numeric","numeric"))
  mapp<-mapp[mapp[,"Chr"] %in% chrsss & !(mapp[,"Start"]>max(pos.geno)+10000) & !(mapp[,"End"]<min(pos.geno)-10000),]
  Mappability<-rep(-1,nrow(geno))
  thechr<-unique(chr.geno)
  for(j in 1:length(thechr)) {
    print(thechr[j])
    slimmap<-mapp[mapp[,"Chr"]==thechr[j],]
    slimgeno<-which(chr.geno==thechr[j])
    for(i in 1:length(slimgeno)) {
      curr<-slimgeno[i]
      rowno<-which(slimmap[,"Chr"]==chr.geno[curr] & slimmap[,"Start"]<pos.geno[curr]-50 & slimmap[,"End"]>pos.geno[curr]+50)
      if(length(rowno)==1) {
        Mappability[curr]<-slimmap[rowno,"Score"]
      }
    }
  }
  rlt<-cbind(geno,Mappability)
  write.table(rlt, ofn, row.names=FALSE, col.names=TRUE, sep="\t", quote=FALSE)
}


