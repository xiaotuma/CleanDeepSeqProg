
CODEDIR=./code/
DATADIR=./code/
#CODEDIR=/rgs01/project_space/zhanggrp/PanTARGET/zhanggrp/xma/scripts/highdepth/code_v3/CleanDeepSeq/code/
#DATADIR=/rgs01/project_space/zhanggrp/PanTARGET/zhanggrp/xma/scripts/highdepth/code_v3/CleanDeepSeq/data/

COUNTER=${CODEDIR}/cleandeepseq.pl
GENOTYPER=${CODEDIR}/genotyper_slim.pl
MAPPING=${CODEDIR}/add_mappability_score.r
CPG=${CODEDIR}/add_CpGIsland_score.r
Vis1Flank=${CODEDIR}/do_plot_1flank_slim.R
Vis3Flank=${CODEDIR}/do_plot_3flank_slim.R

MARKERFN=${DATADIR}/markers.txt
mappable=${DATADIR}/hg19_wgEncodeCrgMapabilityAlign100mer_slim.wg
cpgisland=${DATADIR}/hg19_cpgIslandExt_slim.txt

if [ $# -ne 2 ]; then
  echo "Usage: sh ~ <bam.ifn> <visual_cvg>"
  exit 1
fi

QCUTS=30
mCVG=30
readQcut=20
readFcut=0.05
TRIMLEN=5

bam=$1
VisMinCvg=$2

IFN=`echo ${bam} | awk -F'/' '{print $NF}'`
ofn=counts.$IFN.txt

perl ${COUNTER} ${bam} ${ofn} ${QCUTS} ${mCVG} ${readQcut} ${readFcut} ${TRIMLEN}

GenoCvgCut=50
GenoMinMAF=0.05
GenoMinMut=5
Flank=5
oCut=100
Qcut=30
genoofn=geno_Q${Qcut}.${ofn}
perl ${GENOTYPER} ${ofn} ${GenoCvgCut} ${GenoMinMAF} ${GenoMinMut} ${Flank} ${oCut} ${Qcut} ${genoofn}
mappofn=mapp.${genoofn}
Rscript ${MAPPING} ${genoofn} ${mappable} ${mappofn}
cpgofn=cpg.${mappofn}
Rscript ${CPG} ${mappofn} ${cpgisland} ${cpgofn}
rm ${genoofn} ${mappofn}

Rscript ${Vis1Flank} ${MARKERFN}  ${cpgofn} ${VisMinCvg}
Rscript ${Vis3Flank} ${MARKERFN}  ${cpgofn} ${VisMinCvg}

