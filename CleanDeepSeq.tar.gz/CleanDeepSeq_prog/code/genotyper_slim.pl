
use strict;
use warnings;


if($#ARGV!=7) {
  print("Usage: perl ~ <ifn>\n");
  print("              <genotype.cvg.cut | 50>\n");
  print("              <genotype.min.MAF | 0.05 >\n");
  print("              <genotype.min.Mut | 5>\n");
  print("              <flank.base.N     | 4>\n");
  print("              <output.cvg.Cut   | 50>\n");
  print("              <qaul.cut.of.count| 30 or 38>\n");
  print("              <ofn>\n");
}

if($#ARGV==7) {
  my $ifn=$ARGV[0];
  my $genotypeCvgCut=$ARGV[1];
  my $minMAF=$ARGV[2];
  my $minMut=$ARGV[3];
  my $nFlank=$ARGV[4];
  my $oCvg=$ARGV[5];
  my $Qcut=$ARGV[6];
  my $ofn=$ARGV[7];
  my %data;
  my $ifh;
  my $theA;
  my $theC;
  my $theG;
  my $theT;
  my $theN;

#Chr.Pos Pos     A_Q_0   C_Q_0   G_Q_0   T_Q_0   N_Q_0   A_Q_30  C_Q_30  G_Q_30  T_Q_30  N_Q_30

  open($ifh,"<$ifn") or die "cannot open file $ifn\n";  
  while(my $line=<$ifh>) {
    chomp $line;
    my @eles = split /\t/, $line;
    if($line =~ /Chr.Pos/) {
      for(my $uu=0;$uu<=$#eles;$uu++) {
        $theA = $uu if($eles[$uu] =~ /A_Q_$Qcut/);
        $theC = $uu if($eles[$uu] =~ /C_Q_$Qcut/);
        $theG = $uu if($eles[$uu] =~ /G_Q_$Qcut/);
        $theT = $uu if($eles[$uu] =~ /T_Q_$Qcut/);
        $theN = $uu if($eles[$uu] =~ /N_Q_$Qcut/);
      }
      #print $line,"\n";
      #print "A: $theA  C: $theC  G: $theG  T: $theT  N: $theN\n";
      next;
    }
    next if($eles[$theN]<=$genotypeCvgCut);
    $data{$eles[0]} = {};
    $data{$eles[0]}->{A} = $eles[$theA]; #using Q38; start from 22 if using Q30
    $data{$eles[0]}->{C} = $eles[$theC];
    $data{$eles[0]}->{G} = $eles[$theG];
    $data{$eles[0]}->{T} = $eles[$theT];
    $data{$eles[0]}->{N} = $eles[$theN];
    $data{$eles[0]}->{fA} = $data{$eles[0]}->{A}/$data{$eles[0]}->{N};
    $data{$eles[0]}->{fC} = $data{$eles[0]}->{C}/$data{$eles[0]}->{N};
    $data{$eles[0]}->{fG} = $data{$eles[0]}->{G}/$data{$eles[0]}->{N};
    $data{$eles[0]}->{fT} = $data{$eles[0]}->{T}/$data{$eles[0]}->{N};
    $data{$eles[0]}->{fA} = sprintf("%.3f",$data{$eles[0]}->{fA}*100) if($data{$eles[0]}->{A}>0);
    $data{$eles[0]}->{fC} = sprintf("%.3f",$data{$eles[0]}->{fC}*100) if($data{$eles[0]}->{C}>0);
    $data{$eles[0]}->{fG} = sprintf("%.3f",$data{$eles[0]}->{fG}*100) if($data{$eles[0]}->{G}>0);
    $data{$eles[0]}->{fT} = sprintf("%.3f",$data{$eles[0]}->{fT}*100) if($data{$eles[0]}->{T}>0);
    
    my $genotype = "";
    $genotype .= "A" if($data{$eles[0]}->{fA}>=$minMAF*100  and $data{$eles[0]}->{A}>$minMut);
    $genotype .= "C" if($data{$eles[0]}->{fC}>=$minMAF*100  and $data{$eles[0]}->{C}>$minMut);
    $genotype .= "G" if($data{$eles[0]}->{fG}>=$minMAF*100  and $data{$eles[0]}->{G}>$minMut);
    $genotype .= "T" if($data{$eles[0]}->{fT}>=$minMAF*100  and $data{$eles[0]}->{T}>$minMut);
    $data{$eles[0]}->{genotype}=$genotype;
  }
  foreach my $idx (keys %data) {
    my @indexx=split /\./, $idx;
    my $chr = $indexx[0];
    my $pos = $indexx[1];
    for(my $i=1;$i<=$nFlank;$i++) {
      my $uu = $chr . "." . ($pos-$i);
      $data{$idx}->{flank}->{"N" . $i} = $data{$uu}->{genotype} if(exists $data{$uu});
      $uu = $chr . "." . ($pos+$i);
      $data{$idx}->{flank}->{"P" . $i} = $data{$uu}->{genotype} if(exists $data{$uu});      
    }
  }
  close($ifh);
  my $ofh;
  open($ofh,">$ofn") or die "cannot open file $ofn\n";  
  print $ofh "Chr\tPos\tA\tC\tG\tT\tN\tgeno\tApcnt\tCpcnt\tGpcnt\tTpcnt"; 
  for (my $i=$nFlank;$i>=1;$i--) {
    print $ofh "\t","N" . $i;
  }
  for (my $i=1;$i<=$nFlank;$i++) {
    print $ofh "\t","P" . $i;
  }
  print $ofh "\n";
  foreach my $idx (sort keys %data) {
    next if (not exists $data{$idx}->{flank});
    my @indexx=split /\./, $idx;
    if($data{$idx}->{N}>$oCvg) {
      print $ofh $indexx[0],"\t",$indexx[1];
      print $ofh "\t",$data{$idx}->{A},"\t",$data{$idx}->{C},"\t",$data{$idx}->{G},"\t",$data{$idx}->{T},"\t",$data{$idx}->{N},"\t",$data{$idx}->{genotype}; 
      print $ofh "\t",$data{$idx}->{fA},"\t",$data{$idx}->{fC},"\t",$data{$idx}->{fG},"\t",$data{$idx}->{fT}; 
      for (my $i=$nFlank;$i>=1;$i--) {
        print $ofh "\t",$data{$idx}->{flank}->{"N" . $i}  if(exists $data{$idx}->{flank}->{"N" . $i});
        print $ofh "\t "  if(not exists $data{$idx}->{flank}->{"N" . $i});
      }
      for (my $i=1;$i<=$nFlank;$i++) {
        print $ofh "\t",$data{$idx}->{flank}->{"P" . $i} if (exists $data{$idx}->{flank}->{"P" . $i});
        print $ofh "\t " if (not exists $data{$idx}->{flank}->{"P" . $i});
      }
      print $ofh "\n";
    }
  }
  close($ofh);
}

