median_offset<-0.1
label.x<-0-2.5

make_context<-function(Lk,Rk) {
  library(gtools)
  bases<-c("A","C","G","T")
  Index<-permutations(n=4,r=Lk+1+Rk, v=bases, repeats.allowed=TRUE)
  Lnames<-NULL
  Rnames<-NULL
  if(Lk>0) Lnames<-paste("N",Lk:1,sep="")
  if(Rk>0) Rnames<-paste("P",1:Rk,sep="")
  colnames(Index)<-c("R",Lnames,Rnames)
  rlt<-matrix("",nrow=nrow(Index)*3,ncol=ncol(Index)+1)
  colnames(rlt)<-c(colnames(Index),"M")
  for(i in 1:nrow(Index)) {
    muts<-setdiff(bases, Index[i,"R"])
    for(j in 1:3) {
      rlt[(i-1)*3+j,"M"]<-muts[j]
      for(k in 1:ncol(Index)) {
        rlt[(i-1)*3+j,colnames(Index)]<-Index[i,colnames(Index)]
      }
    }
  }
  ret<-cbind(rlt[,Lnames],R=rlt[,"R"],rlt[,Rnames],M=rlt[,"M"])
  colnames(ret)<-c(Lnames,"R",Rnames,"M")
  revRet<-ret[,c(rev(Rnames),"R",rev(Lnames),"M")]
  colnames(revRet)<-paste("r",colnames(revRet),sep="")  
  for(j in 1:ncol(revRet)) {
    revRet[revRet[,j]=="A",j]<-"X"
	revRet[revRet[,j]=="T",j]<-"A"
	revRet[revRet[,j]=="X",j]<-"T"
    revRet[revRet[,j]=="C",j]<-"X"
	revRet[revRet[,j]=="G",j]<-"C"
	revRet[revRet[,j]=="X",j]<-"G"
  }
  fwd_pretty<-apply(cbind(ret[,Lnames],"(",ret[,"R"],">",ret[,"M"],")",ret[,Rnames]),1,paste,collapse="")
  rev_pretty<-apply(cbind("(",revRet[,"rR"],">",revRet[,"rM"],")"),1,paste,collapse="")
  if(length(Rnames)>0) {
    rev_pretty<-apply(cbind(revRet[,paste("r",rev(Rnames),sep="")],rev_pretty),1,paste,collapse="")
  }
  if(length(Lnames)>0) {
    rev_pretty<-apply(cbind(rev_pretty,revRet[,paste("r",rev(Lnames),sep="")]),1,paste,collapse="")
  }
  final<-cbind(ret, revRet,Forward=fwd_pretty,Reverse=rev_pretty)
  colnames(final)<-gsub("rX","rN",gsub("rN","rP",gsub("rP","rX",colnames(final))))
  return(final)
}

count_bins<-function(vec, minu, maxu, nbin, zero_label) {
  width<-(maxu-minu)/nbin
  binstart<-minu+(0:(nbin-1))*width
  binend<-minu+(1:nbin)*width
  binend[nbin]<-binend[nbin]+0.0001
  bin_center<-minu+(1:nbin)*width-0.5*width
  bin_counts<-rep(0,nbin)
  for(i in 1:nbin) {
    bin_counts[i]<-sum(vec>=binstart[i] & vec<binend[i])  
  }
  zeros<-sum(vec<minu)
  bin_center<-c(zero_label,bin_center)
  binstart<-c(zero_label,binstart)
  binend<-c(zero_label,binend)
  bin_counts<-c(zeros,bin_counts)
  rlt<-cbind(bin_center,bin_counts,binstart,binend)
  return(rlt)
}

plot_bars<-function(histt,yy) {
  maxyy<-max(histt[,"bin_counts"])  
  width<-max(histt[,"binend"]-histt[,"binstart"])
  for(i in 1:nrow(histt)) {
    theyy<-0.4*histt[i,"bin_counts"]/maxyy
	xleft<-histt[i,"binstart"]
	xright<-histt[i,"binend"]
	ytop<-yy+theyy
	ybottom<-yy-theyy
	if(xleft==xright) {
	  xleft<-xleft-width*0.5
	  xright<-xright+width*0.5
	}
	rect(xleft=xleft, xright=xright, ytop=ytop, ybottom=ybottom,col="#BBBBBB",border=NA)	
  }
}



plot_one_flank0<-function(ifn,minCvg=200000,flank=0,markerfn="markers.txt",vaf_min_log=-5, vaf_Max_log=-1, bins=40, zero_label=-6,cex.label=1,cex.points=1,ladder.cols=c("red","blue","black"),ladder.vals=c(0.0005, 0.001,0.002),main) {
  dt<-read.table(ifn,header=TRUE,sep="\t")
  colnames(dt)[colnames(dt)=="geno"]<-"R"
  dt[dt[,"Chr"]=="chr1" & as.integer(dt[,"Pos"])>153391708 & as.integer(dt[,"Pos"])<153391855,"Mappability"]<-1
  dt<-dt[dt[,"Mappability"]==1 & 
         as.character(dt[,"R"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"N1"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"P1"]) %in% c("A","C","G","T"),]
  row.names(dt)<-apply(cbind(as.character(dt[,"Chr"]),as.character(dt[,"Pos"])),1,paste,collapse=".")
  
  if(!is.na(markerfn)) {
    marker<-read.table(markerfn,header=TRUE,sep="\t",colClass="character")
	row.names(marker)<-apply(marker[,c("Chr","Pos")],1,paste,collapse=".")
  }
  isSomatic<-1*(row.names(dt) %in% row.names(marker))
  dt<-cbind(dt,isSomatic)
  dt<-dt[dt[,"N"]>minCvg | dt[,"isSomatic"]==1,]  
  thecon<-make_context(Lk=flank,Rk=flank)
  needcols<-setdiff(colnames(thecon),c("M","rR","rM","Forward","Reverse"))
  
  plot(-100,xlim=c(zero_label-0.5,0+0.5),ylim=c(-0.1,nrow(thecon)+1),xlab="",ylab="",xaxt="n",yaxt="n",bty="n",main="")  
  text(zero_label*0.5,nrow(thecon)+0.5,main,cex=1)
  for(i in 2:6) {
    lines(c(-i,-i),c(0,nrow(thecon)-1),col="#EEEEEE",lwd=0.5)
  }
  axis(1,at=c(-c(6:2)),labels=c("-6","-5","-4","-3","-2"),cex.axis=cex.label)
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    lines(c(zero_label,vaf_Max_log),c(yyy,yyy),lwd=0.5,col="#DDDDDD")
  }
  for(i in 1:length(ladder.vals)) {
    lines(c(log10(ladder.vals[i]),log10(ladder.vals[i])),c(-0.4,nrow(thecon)-0.4),col=ladder.cols[i])
  }
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    needrow<-rep(TRUE,nrow(dt))
	for(j in 1:length(needcols)) {
	  needrow<-needrow & as.character(dt[,needcols[j]])==thecon[i,needcols[j]]
	}
	tmp<-dt[needrow,]
	vaf<-log10(tmp[,thecon[i,"M"]]/(0.00001+tmp[,"N"]))
	names(vaf)<-row.names(tmp)
	isFG<-rep(0,nrow(tmp))
	isFG[row.names(tmp) %in% row.names(marker)[marker[,"Mut"]==thecon[i,"M"]]]<-1	
	FG<-vaf[isFG==1]
	BG<-vaf[isFG==0]	
	histt<-count_bins(vec=BG, minu=vaf_min_log, maxu=vaf_Max_log, nbin=bins, zero_label=-6)	
	plot_bars(histt,yy=yyy)	
	txt<-paste(c(thecon[i,"Forward"], " (",length(BG),")"),collapse="")	
	text(label.x,yyy,txt,cex=cex.label,pos=4)
	med<-sprintf("%.1f",median(BG))
	text(zero_label,yyy+median_offset,med,cex=cex.label,pos=4)
	if(length(FG)>0) {
	  for(j in 1:length(FG)) {
	    rrrr<-rnorm(1,mean=0,sd=0.05)
		if(rrrr>0.2) rrrr<-0.2
		if(rrrr<0-0.2) rrrr<-0-0.2
		coll<-""
		if(marker[names(FG)[j],"MutAllele"] %in% c("4v4","BRAF.V600E")) coll<-ladder.cols[3]
		if(marker[names(FG)[j],"MutAllele"] %in% c("2v4")) coll<-ladder.cols[2]
		if(marker[names(FG)[j],"MutAllele"] %in% c("1v4","1v2")) coll<-ladder.cols[1]
	    points(FG[j], yyy+rrrr,cex=cex.points,pch=16,col=coll)
	  }
	}
  }
}



plot_one_flank1_C2T<-function(ifn,minCvg=200000,flank=1,markerfn="markers.txt",vaf_min_log=-5, vaf_Max_log=-1, bins=40, zero_label=-6,cex.label=1,cex.points=1,ladder.cols=c("red","blue","black"),ladder.vals=c(0.0005, 0.001,0.002),main) {
  dt<-read.table(ifn,header=TRUE,sep="\t")
  colnames(dt)[colnames(dt)=="geno"]<-"R"
  dt[dt[,"Chr"]=="chr1" & as.integer(dt[,"Pos"])>153391708 & as.integer(dt[,"Pos"])<153391855,"Mappability"]<-1
  dt<-dt[dt[,"Mappability"]==1 & 
         as.character(dt[,"R"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"N1"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"P1"]) %in% c("A","C","G","T"),]
  row.names(dt)<-apply(cbind(as.character(dt[,"Chr"]),as.character(dt[,"Pos"])),1,paste,collapse=".")
  
  if(!is.na(markerfn)) {
    marker<-read.table(markerfn,header=TRUE,sep="\t",colClass="character")
	row.names(marker)<-apply(marker[,c("Chr","Pos")],1,paste,collapse=".")
  }
  isSomatic<-1*(row.names(dt) %in% row.names(marker))
  dt<-cbind(dt,isSomatic)
  dt<-dt[dt[,"N"]>minCvg | dt[,"isSomatic"]==1,]  
  thecon<-make_context(Lk=flank,Rk=flank)
  thecon<-thecon[thecon[,"R"]=="C" & thecon[,"M"]=="T",]
  needcols<-setdiff(colnames(thecon),c("M","rR","rM","Forward","Reverse","rN1","rN2","rN3","rN4","rN5","rN6","rP1","rP2","rP3","rP4","rP5","rP6"))
  
  plot(-100,xlim=c(zero_label-0.5,0+0.5),ylim=c(-0.1,nrow(thecon)+1),xlab="",ylab="",xaxt="n",yaxt="n",bty="n",main="")  
  text(zero_label*0.5,nrow(thecon)+0.5,paste(c(main,"(C>T)"),collapse=""),cex=1)
  for(i in 2:6) {
    lines(c(-i,-i),c(0,nrow(thecon)-1),col="#EEEEEE",lwd=0.5)
  }
  axis(1,at=c(-c(6:2)),labels=c("-6","-5","-4","-3","-2"),cex.axis=cex.label)
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    lines(c(zero_label,vaf_Max_log),c(yyy,yyy),lwd=0.5,col="#DDDDDD")
  }
  for(i in 1:length(ladder.vals)) {
    yyy<-nrow(thecon)-i
    lines(c(log10(ladder.vals[i]),log10(ladder.vals[i])),c(-0.4,nrow(thecon)-0.4),col=ladder.cols[i])
  }
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    needrow<-rep(TRUE,nrow(dt))
	for(j in 1:length(needcols)) {
	  needrow<-needrow & as.character(dt[,needcols[j]])==thecon[i,needcols[j]]
	}
	tmp<-dt[needrow,]
	vaf<-log10(tmp[,thecon[i,"M"]]/(0.00001+tmp[,"N"]))
	names(vaf)<-row.names(tmp)
	isFG<-rep(0,nrow(tmp))
	isFG[row.names(tmp) %in% row.names(marker)[marker[,"Mut"]==thecon[i,"M"]]]<-1	
	FG<-vaf[isFG==1]
	BG<-vaf[isFG==0]
	histt<-count_bins(vec=BG, minu=vaf_min_log, maxu=vaf_Max_log, nbin=bins, zero_label=-6)	
	plot_bars(histt,yy=yyy)	
	txt<-paste(c(thecon[i,"Forward"], " (",length(BG),")"),collapse="")
	text(label.x,yyy,txt,cex=cex.label,pos=4)
	med<-sprintf("%.1f",median(BG))
	text(zero_label,yyy+median_offset,med,cex=cex.label,pos=4)
	if(length(FG)>0) {
	  for(j in 1:length(FG)) {
	    rrrr<-rnorm(1,mean=0,sd=0.05)
		if(rrrr>0.2) rrrr<-0.2
		if(rrrr<0-0.2) rrrr<-0-0.2
		coll<-""
		if(marker[names(FG)[j],"MutAllele"] %in% c("4v4","BRAF.V600E")) coll<-ladder.cols[3]
		if(marker[names(FG)[j],"MutAllele"] %in% c("2v4")) coll<-ladder.cols[2]
		if(marker[names(FG)[j],"MutAllele"] %in% c("1v4","1v2")) coll<-ladder.cols[1]
	    points(FG[j], yyy+rrrr,cex=cex.points,pch=16,col=coll)
	  }
	}
  }
}




plot_one_flank1_G2A<-function(ifn,minCvg=200000,flank=1,markerfn="markers.txt",vaf_min_log=-5, vaf_Max_log=-1, bins=40, zero_label=-6,cex.label=1,cex.points=1,ladder.cols=c("red","blue","black"),ladder.vals=c(0.0005, 0.001,0.002),main) {
  dt<-read.table(ifn,header=TRUE,sep="\t")
  colnames(dt)[colnames(dt)=="geno"]<-"R"
  dt[dt[,"Chr"]=="chr1" & as.integer(dt[,"Pos"])>153391708 & as.integer(dt[,"Pos"])<153391855,"Mappability"]<-1
  dt<-dt[dt[,"Mappability"]==1 & 
         as.character(dt[,"R"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"N1"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"P1"]) %in% c("A","C","G","T"),]
  row.names(dt)<-apply(cbind(as.character(dt[,"Chr"]),as.character(dt[,"Pos"])),1,paste,collapse=".")
  
  if(!is.na(markerfn)) {
    marker<-read.table(markerfn,header=TRUE,sep="\t",colClass="character")
	row.names(marker)<-apply(marker[,c("Chr","Pos")],1,paste,collapse=".")
  }
  isSomatic<-1*(row.names(dt) %in% row.names(marker))
  dt<-cbind(dt,isSomatic)
  dt<-dt[dt[,"N"]>minCvg | dt[,"isSomatic"]==1,]  
  thecon<-make_context(Lk=flank,Rk=flank)
  thecon<-thecon[thecon[,"R"]=="G" & thecon[,"M"]=="A",]
  thecon<-thecon[order(thecon[,"Reverse"]),]
  needcols<-setdiff(colnames(thecon),c("M","rR","rM","Forward","Reverse","rN1","rN2","rN3","rN4","rN5","rN6","rP1","rP2","rP3","rP4","rP5","rP6"))
  
  plot(-100,xlim=c(zero_label-0.5,0+0.5),ylim=c(-0.1,nrow(thecon)+1),xlab="",ylab="",xaxt="n",yaxt="n",bty="n",main="")  
  text(zero_label*0.5,nrow(thecon)+0.5,paste(c(main,"(G>A)"),collapse=""),cex=1)
  for(i in 2:6) {
    lines(c(-i,-i),c(0,nrow(thecon)-1),col="#EEEEEE",lwd=0.5)
  }
  axis(1,at=c(-c(6:2)),labels=c("-6","-5","-4","-3","-2"),cex.axis=cex.label)
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    lines(c(zero_label,vaf_Max_log),c(yyy,yyy),lwd=0.5,col="#DDDDDD")
  }
  for(i in 1:length(ladder.vals)) {
    lines(c(log10(ladder.vals[i]),log10(ladder.vals[i])),c(-0.4,nrow(thecon)-0.4),col=ladder.cols[i])
  }
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    needrow<-rep(TRUE,nrow(dt))
	for(j in 1:length(needcols)) {
	  needrow<-needrow & as.character(dt[,needcols[j]])==thecon[i,needcols[j]]
	}
	tmp<-dt[needrow,]
	vaf<-log10(tmp[,thecon[i,"M"]]/(0.00001+tmp[,"N"]))
	names(vaf)<-row.names(tmp)
	isFG<-rep(0,nrow(tmp))
	isFG[row.names(tmp) %in% row.names(marker)[marker[,"Mut"]==thecon[i,"M"]]]<-1	
	FG<-vaf[isFG==1]
	BG<-vaf[isFG==0]
	histt<-count_bins(vec=BG, minu=vaf_min_log, maxu=vaf_Max_log, nbin=bins, zero_label=-6)
	
	plot_bars(histt,yy=yyy)	
	txt<-paste(c(thecon[i,"Forward"], " (",length(BG),")"),collapse="")
	text(label.x,yyy,txt,cex=cex.label,pos=4)
	med<-sprintf("%.1f",median(BG))
	text(zero_label,yyy+median_offset,med,cex=cex.label,pos=4)
	if(length(FG)>0) {
	  for(j in 1:length(FG)) {
	    rrrr<-rnorm(1,mean=0,sd=0.05)
		if(rrrr>0.2) rrrr<-0.2
		if(rrrr<0-0.2) rrrr<-0-0.2
		coll<-""
		if(marker[names(FG)[j],"MutAllele"] %in% c("4v4","BRAF.V600E")) coll<-ladder.cols[3]
		if(marker[names(FG)[j],"MutAllele"] %in% c("2v4")) coll<-ladder.cols[2]
		if(marker[names(FG)[j],"MutAllele"] %in% c("1v4","1v2")) coll<-ladder.cols[1]
	    points(FG[j], yyy+rrrr,cex=cex.points,pch=16,col=coll)
	  }
	}
  }
}





plot_one_flank1<-function(ifn,minCvg=200000,markerfn="markers.txt",vaf_min_log=-5, vaf_Max_log=-1, bins=40, zero_label=-6,cex.label=1,cex.points=1,ladder.cols=c("red","blue","black"),ladder.vals=c(0.0005, 0.001,0.002),main) {
  flank<-1  
  dt<-read.table(ifn,header=TRUE,sep="\t")
  colnames(dt)[colnames(dt)=="geno"]<-"R"
  dt[dt[,"Chr"]=="chr1" & as.integer(dt[,"Pos"])>153391708 & as.integer(dt[,"Pos"])<153391855,"Mappability"]<-1
  dt<-dt[dt[,"Mappability"]==1 & 
         as.character(dt[,"R"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"N1"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"P1"]) %in% c("A","C","G","T"),]
  row.names(dt)<-apply(cbind(as.character(dt[,"Chr"]),as.character(dt[,"Pos"])),1,paste,collapse=".")  
  if(!is.na(markerfn)) {
    marker<-read.table(markerfn,header=TRUE,sep="\t",colClass="character")
	row.names(marker)<-apply(marker[,c("Chr","Pos")],1,paste,collapse=".")
  }
  isSomatic<-1*(row.names(dt) %in% row.names(marker))
  dt<-cbind(dt,isSomatic)
  dt<-dt[dt[,"N"]>minCvg | dt[,"isSomatic"]==1,]  
  thecon<-make_context(Lk=flank,Rk=flank)
  needcols<-setdiff(colnames(thecon),c("M","rR","rM","Forward","Reverse","rN1","rP1"))
  bases<-c("A","C","G","T")
  for(i in 1:length(bases)) {
    for(j in 1:length(bases)) {
	  if(j!=i) {
	    reff<-bases[i]
	    mutt<-bases[j]
		needed.context<-thecon[thecon[,"R"]==reff & thecon[,"M"]==mutt,]
		
		plot(-100,xlim=c(zero_label-0.5,0+0.5),ylim=c(-0.1,nrow(needed.context)+1),xlab="",ylab="",xaxt="n",yaxt="n",bty="n",main="")
		text(zero_label*0.5,nrow(needed.context)+0.5,main,cex=1)
        for(ll in 2:6) {
          lines(c(-ll,-ll),c(0,nrow(needed.context)-1),col="#EEEEEE",lwd=0.5)
        }
		for(ll in 1:nrow(needed.context)) {
		  yyy<-nrow(needed.context)-ll
		  lines(c(zero_label,vaf_Max_log),c(yyy,yyy),lwd=0.5,col="#DDDDDD")
		}
        axis(1,at=c(-c(6:2)),labels=c("-6","-5","-4","-3","-2"),cex.axis=cex.label)        
        for(ll in 1:length(ladder.vals)) {
          lines(c(log10(ladder.vals[ll]),log10(ladder.vals[ll])),c(-0.4,nrow(needed.context)-0.4),col=ladder.cols[ll])
        }
		
		for(k in 1:nrow(needed.context)) {
		  yyy<-nrow(needed.context)-k
		  needrow<-rep(TRUE,nrow(dt))
		  for(m in 1:length(needcols)) {
	        needrow<-needrow & as.character(dt[,needcols[m]])==needed.context[k,needcols[m]]
	      }
		  tmp<-dt[needrow,]
		  vaf<-log10(tmp[,needed.context[k,"M"]]/(0.00001+tmp[,"N"]))
		  names(vaf)<-row.names(tmp)
		  isFG<-rep(0,nrow(tmp))
		  isFG[row.names(tmp) %in% row.names(marker)[marker[,"Mut"]==needed.context[k,"M"]]]<-1	
		  FG<-vaf[isFG==1]
		  BG<-vaf[isFG==0]
		  histt<-count_bins(vec=BG, minu=vaf_min_log, maxu=vaf_Max_log, nbin=bins, zero_label=-6)		  
	      plot_bars(histt,yy=yyy)	
	      txt<-paste(c(needed.context[k,"Forward"], " (",length(BG),")"),collapse="")	
	      text(label.x,yyy,txt,cex=cex.label,pos=4)
	      med<-sprintf("%.1f",median(BG))
	      text(zero_label,yyy+median_offset,med,cex=cex.label,pos=4)
	      if(length(FG)>0) {
	        for(n in 1:length(FG)) {
	          rrrr<-rnorm(1,mean=0,sd=0.05)
		      if(rrrr>0.2) rrrr<-0.2
		      if(rrrr<0-0.2) rrrr<-0-0.2
		      coll<-""
		      if(marker[names(FG)[n],"MutAllele"] %in% c("4v4","BRAF.V600E")) coll<-ladder.cols[3]
		      if(marker[names(FG)[n],"MutAllele"] %in% c("2v4")) coll<-ladder.cols[2]
		      if(marker[names(FG)[n],"MutAllele"] %in% c("1v4","1v2")) coll<-ladder.cols[1]
	          points(FG[n], yyy+rrrr,cex=cex.points,pch=16,col=coll)
			}
	      }
		}
	  }
	}  
  }  
}
median_offset<-0.1
label.x<-0-2.5

make_context<-function(Lk,Rk) {
  library(gtools)
  bases<-c("A","C","G","T")
  Index<-permutations(n=4,r=Lk+1+Rk, v=bases, repeats.allowed=TRUE)
  Lnames<-NULL
  Rnames<-NULL
  if(Lk>0) Lnames<-paste("N",Lk:1,sep="")
  if(Rk>0) Rnames<-paste("P",1:Rk,sep="")
  colnames(Index)<-c("R",Lnames,Rnames)
  rlt<-matrix("",nrow=nrow(Index)*3,ncol=ncol(Index)+1)
  colnames(rlt)<-c(colnames(Index),"M")
  for(i in 1:nrow(Index)) {
    muts<-setdiff(bases, Index[i,"R"])
    for(j in 1:3) {
      rlt[(i-1)*3+j,"M"]<-muts[j]
      for(k in 1:ncol(Index)) {
        rlt[(i-1)*3+j,colnames(Index)]<-Index[i,colnames(Index)]
      }
    }
  }
  ret<-cbind(rlt[,Lnames],R=rlt[,"R"],rlt[,Rnames],M=rlt[,"M"])
  colnames(ret)<-c(Lnames,"R",Rnames,"M")
  revRet<-ret[,c(rev(Rnames),"R",rev(Lnames),"M")]
  colnames(revRet)<-paste("r",colnames(revRet),sep="")  
  for(j in 1:ncol(revRet)) {
    revRet[revRet[,j]=="A",j]<-"X"
	revRet[revRet[,j]=="T",j]<-"A"
	revRet[revRet[,j]=="X",j]<-"T"
    revRet[revRet[,j]=="C",j]<-"X"
	revRet[revRet[,j]=="G",j]<-"C"
	revRet[revRet[,j]=="X",j]<-"G"
  }
  fwd_pretty<-apply(cbind(ret[,Lnames],"(",ret[,"R"],">",ret[,"M"],")",ret[,Rnames]),1,paste,collapse="")
  rev_pretty<-apply(cbind("(",revRet[,"rR"],">",revRet[,"rM"],")"),1,paste,collapse="")
  if(length(Rnames)>0) {
    rev_pretty<-apply(cbind(revRet[,paste("r",rev(Rnames),sep="")],rev_pretty),1,paste,collapse="")
  }
  if(length(Lnames)>0) {
    rev_pretty<-apply(cbind(rev_pretty,revRet[,paste("r",rev(Lnames),sep="")]),1,paste,collapse="")
  }
  final<-cbind(ret, revRet,Forward=fwd_pretty,Reverse=rev_pretty)
  colnames(final)<-gsub("rX","rN",gsub("rN","rP",gsub("rP","rX",colnames(final))))
  return(final)
}

count_bins<-function(vec, minu, maxu, nbin, zero_label) {
  width<-(maxu-minu)/nbin
  binstart<-minu+(0:(nbin-1))*width
  binend<-minu+(1:nbin)*width
  binend[nbin]<-binend[nbin]+0.0001
  bin_center<-minu+(1:nbin)*width-0.5*width
  bin_counts<-rep(0,nbin)
  for(i in 1:nbin) {
    bin_counts[i]<-sum(vec>=binstart[i] & vec<binend[i])  
  }
  zeros<-sum(vec<minu)
  bin_center<-c(zero_label,bin_center)
  binstart<-c(zero_label,binstart)
  binend<-c(zero_label,binend)
  bin_counts<-c(zeros,bin_counts)
  rlt<-cbind(bin_center,bin_counts,binstart,binend)
  return(rlt)
}

plot_bars<-function(histt,yy) {
  maxyy<-max(histt[,"bin_counts"])  
  width<-max(histt[,"binend"]-histt[,"binstart"])
  for(i in 1:nrow(histt)) {
    theyy<-0.4*histt[i,"bin_counts"]/maxyy
	xleft<-histt[i,"binstart"]
	xright<-histt[i,"binend"]
	ytop<-yy+theyy
	ybottom<-yy-theyy
	if(xleft==xright) {
	  xleft<-xleft-width*0.5
	  xright<-xright+width*0.5
	}
	rect(xleft=xleft, xright=xright, ytop=ytop, ybottom=ybottom,col="#BBBBBB",border=NA)	
  }
}



plot_one_flank0<-function(ifn,minCvg=200000,flank=0,markerfn="markers.txt",vaf_min_log=-5, vaf_Max_log=-1, bins=40, zero_label=-6,cex.label=1,cex.points=1,ladder.cols=c("red","blue","black"),ladder.vals=c(0.0005, 0.001,0.002),main) {
  dt<-read.table(ifn,header=TRUE,sep="\t")
  colnames(dt)[colnames(dt)=="geno"]<-"R"
  dt[dt[,"Chr"]=="chr1" & as.integer(dt[,"Pos"])>153391708 & as.integer(dt[,"Pos"])<153391855,"Mappability"]<-1
  dt<-dt[dt[,"Mappability"]==1 & 
         as.character(dt[,"R"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"N1"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"P1"]) %in% c("A","C","G","T"),]
  row.names(dt)<-apply(cbind(as.character(dt[,"Chr"]),as.character(dt[,"Pos"])),1,paste,collapse=".")
  
  if(!is.na(markerfn)) {
    marker<-read.table(markerfn,header=TRUE,sep="\t",colClass="character")
	row.names(marker)<-apply(marker[,c("Chr","Pos")],1,paste,collapse=".")
  }
  isSomatic<-1*(row.names(dt) %in% row.names(marker))
  dt<-cbind(dt,isSomatic)
  dt<-dt[dt[,"N"]>minCvg | dt[,"isSomatic"]==1,]  
  thecon<-make_context(Lk=flank,Rk=flank)
  needcols<-setdiff(colnames(thecon),c("M","rR","rM","Forward","Reverse"))
  
  plot(-100,xlim=c(zero_label-0.5,0+0.5),ylim=c(-0.1,nrow(thecon)+1),xlab="",ylab="",xaxt="n",yaxt="n",bty="n",main="")  
  text(zero_label*0.5,nrow(thecon)+0.5,main,cex=1)
  for(i in 2:6) {
    lines(c(-i,-i),c(0,nrow(thecon)-1),col="#EEEEEE",lwd=0.5)
  }
  axis(1,at=c(-c(6:2)),labels=c("-6","-5","-4","-3","-2"),cex.axis=cex.label)
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    lines(c(zero_label,vaf_Max_log),c(yyy,yyy),lwd=0.5,col="#DDDDDD")
  }
  for(i in 1:length(ladder.vals)) {
    lines(c(log10(ladder.vals[i]),log10(ladder.vals[i])),c(-0.4,nrow(thecon)-0.4),col=ladder.cols[i])
  }
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    needrow<-rep(TRUE,nrow(dt))
	for(j in 1:length(needcols)) {
	  needrow<-needrow & as.character(dt[,needcols[j]])==thecon[i,needcols[j]]
	}
	tmp<-dt[needrow,]
	vaf<-log10(tmp[,thecon[i,"M"]]/(0.00001+tmp[,"N"]))
	names(vaf)<-row.names(tmp)
	isFG<-rep(0,nrow(tmp))
	isFG[row.names(tmp) %in% row.names(marker)[marker[,"Mut"]==thecon[i,"M"]]]<-1	
	FG<-vaf[isFG==1]
	BG<-vaf[isFG==0]	
	histt<-count_bins(vec=BG, minu=vaf_min_log, maxu=vaf_Max_log, nbin=bins, zero_label=-6)	
	plot_bars(histt,yy=yyy)	
	txt<-paste(c(thecon[i,"Forward"], " (",length(BG),")"),collapse="")	
	text(label.x,yyy,txt,cex=cex.label,pos=4)
	med<-sprintf("%.1f",median(BG))
	text(zero_label,yyy+median_offset,med,cex=cex.label,pos=4)
	if(length(FG)>0) {
	  for(j in 1:length(FG)) {
	    rrrr<-rnorm(1,mean=0,sd=0.05)
		if(rrrr>0.2) rrrr<-0.2
		if(rrrr<0-0.2) rrrr<-0-0.2
		coll<-""
		if(marker[names(FG)[j],"MutAllele"] %in% c("4v4","BRAF.V600E")) coll<-ladder.cols[3]
		if(marker[names(FG)[j],"MutAllele"] %in% c("2v4")) coll<-ladder.cols[2]
		if(marker[names(FG)[j],"MutAllele"] %in% c("1v4","1v2")) coll<-ladder.cols[1]
	    points(FG[j], yyy+rrrr,cex=cex.points,pch=16,col=coll)
	  }
	}
  }
}



plot_one_flank1_C2T<-function(ifn,minCvg=200000,flank=1,markerfn="markers.txt",vaf_min_log=-5, vaf_Max_log=-1, bins=40, zero_label=-6,cex.label=1,cex.points=1,ladder.cols=c("red","blue","black"),ladder.vals=c(0.0005, 0.001,0.002),main) {
  dt<-read.table(ifn,header=TRUE,sep="\t")
  colnames(dt)[colnames(dt)=="geno"]<-"R"
  dt[dt[,"Chr"]=="chr1" & as.integer(dt[,"Pos"])>153391708 & as.integer(dt[,"Pos"])<153391855,"Mappability"]<-1
  dt<-dt[dt[,"Mappability"]==1 & 
         as.character(dt[,"R"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"N1"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"P1"]) %in% c("A","C","G","T"),]
  row.names(dt)<-apply(cbind(as.character(dt[,"Chr"]),as.character(dt[,"Pos"])),1,paste,collapse=".")
  
  if(!is.na(markerfn)) {
    marker<-read.table(markerfn,header=TRUE,sep="\t",colClass="character")
	row.names(marker)<-apply(marker[,c("Chr","Pos")],1,paste,collapse=".")
  }
  isSomatic<-1*(row.names(dt) %in% row.names(marker))
  dt<-cbind(dt,isSomatic)
  dt<-dt[dt[,"N"]>minCvg | dt[,"isSomatic"]==1,]  
  thecon<-make_context(Lk=flank,Rk=flank)
  thecon<-thecon[thecon[,"R"]=="C" & thecon[,"M"]=="T",]
  needcols<-setdiff(colnames(thecon),c("M","rR","rM","Forward","Reverse","rN1","rN2","rN3","rN4","rN5","rN6","rP1","rP2","rP3","rP4","rP5","rP6"))
  
  plot(-100,xlim=c(zero_label-0.5,0+0.5),ylim=c(-0.1,nrow(thecon)+1),xlab="",ylab="",xaxt="n",yaxt="n",bty="n",main="")  
  text(zero_label*0.5,nrow(thecon)+0.5,paste(c(main,"(C>T)"),collapse=""),cex=1)
  for(i in 2:6) {
    lines(c(-i,-i),c(0,nrow(thecon)-1),col="#EEEEEE",lwd=0.5)
  }
  axis(1,at=c(-c(6:2)),labels=c("-6","-5","-4","-3","-2"),cex.axis=cex.label)
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    lines(c(zero_label,vaf_Max_log),c(yyy,yyy),lwd=0.5,col="#DDDDDD")
  }
  for(i in 1:length(ladder.vals)) {
    yyy<-nrow(thecon)-i
    lines(c(log10(ladder.vals[i]),log10(ladder.vals[i])),c(-0.4,nrow(thecon)-0.4),col=ladder.cols[i])
  }
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    needrow<-rep(TRUE,nrow(dt))
	for(j in 1:length(needcols)) {
	  needrow<-needrow & as.character(dt[,needcols[j]])==thecon[i,needcols[j]]
	}
	tmp<-dt[needrow,]
	vaf<-log10(tmp[,thecon[i,"M"]]/(0.00001+tmp[,"N"]))
	names(vaf)<-row.names(tmp)
	isFG<-rep(0,nrow(tmp))
	isFG[row.names(tmp) %in% row.names(marker)[marker[,"Mut"]==thecon[i,"M"]]]<-1	
	FG<-vaf[isFG==1]
	BG<-vaf[isFG==0]
	histt<-count_bins(vec=BG, minu=vaf_min_log, maxu=vaf_Max_log, nbin=bins, zero_label=-6)	
	plot_bars(histt,yy=yyy)	
	txt<-paste(c(thecon[i,"Forward"], " (",length(BG),")"),collapse="")
	text(label.x,yyy,txt,cex=cex.label,pos=4)
	med<-sprintf("%.1f",median(BG))
	text(zero_label,yyy+median_offset,med,cex=cex.label,pos=4)
	if(length(FG)>0) {
	  for(j in 1:length(FG)) {
	    rrrr<-rnorm(1,mean=0,sd=0.05)
		if(rrrr>0.2) rrrr<-0.2
		if(rrrr<0-0.2) rrrr<-0-0.2
		coll<-""
		if(marker[names(FG)[j],"MutAllele"] %in% c("4v4","BRAF.V600E")) coll<-ladder.cols[3]
		if(marker[names(FG)[j],"MutAllele"] %in% c("2v4")) coll<-ladder.cols[2]
		if(marker[names(FG)[j],"MutAllele"] %in% c("1v4","1v2")) coll<-ladder.cols[1]
	    points(FG[j], yyy+rrrr,cex=cex.points,pch=16,col=coll)
	  }
	}
  }
}




plot_one_flank1_G2A<-function(ifn,minCvg=200000,flank=1,markerfn="markers.txt",vaf_min_log=-5, vaf_Max_log=-1, bins=40, zero_label=-6,cex.label=1,cex.points=1,ladder.cols=c("red","blue","black"),ladder.vals=c(0.0005, 0.001,0.002),main) {
  dt<-read.table(ifn,header=TRUE,sep="\t")
  colnames(dt)[colnames(dt)=="geno"]<-"R"
  dt[dt[,"Chr"]=="chr1" & as.integer(dt[,"Pos"])>153391708 & as.integer(dt[,"Pos"])<153391855,"Mappability"]<-1
  dt<-dt[dt[,"Mappability"]==1 & 
         as.character(dt[,"R"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"N1"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"P1"]) %in% c("A","C","G","T"),]
  row.names(dt)<-apply(cbind(as.character(dt[,"Chr"]),as.character(dt[,"Pos"])),1,paste,collapse=".")
  
  if(!is.na(markerfn)) {
    marker<-read.table(markerfn,header=TRUE,sep="\t",colClass="character")
	row.names(marker)<-apply(marker[,c("Chr","Pos")],1,paste,collapse=".")
  }
  isSomatic<-1*(row.names(dt) %in% row.names(marker))
  dt<-cbind(dt,isSomatic)
  dt<-dt[dt[,"N"]>minCvg | dt[,"isSomatic"]==1,]  
  thecon<-make_context(Lk=flank,Rk=flank)
  thecon<-thecon[thecon[,"R"]=="G" & thecon[,"M"]=="A",]
  thecon<-thecon[order(thecon[,"Reverse"]),]
  needcols<-setdiff(colnames(thecon),c("M","rR","rM","Forward","Reverse","rN1","rN2","rN3","rN4","rN5","rN6","rP1","rP2","rP3","rP4","rP5","rP6"))
  
  plot(-100,xlim=c(zero_label-0.5,0+0.5),ylim=c(-0.1,nrow(thecon)+1),xlab="",ylab="",xaxt="n",yaxt="n",bty="n",main="")  
  text(zero_label*0.5,nrow(thecon)+0.5,paste(c(main,"(G>A)"),collapse=""),cex=1)
  for(i in 2:6) {
    lines(c(-i,-i),c(0,nrow(thecon)-1),col="#EEEEEE",lwd=0.5)
  }
  axis(1,at=c(-c(6:2)),labels=c("-6","-5","-4","-3","-2"),cex.axis=cex.label)
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    lines(c(zero_label,vaf_Max_log),c(yyy,yyy),lwd=0.5,col="#DDDDDD")
  }
  for(i in 1:length(ladder.vals)) {
    lines(c(log10(ladder.vals[i]),log10(ladder.vals[i])),c(-0.4,nrow(thecon)-0.4),col=ladder.cols[i])
  }
  for(i in 1:nrow(thecon)) {
    yyy<-nrow(thecon)-i
    needrow<-rep(TRUE,nrow(dt))
	for(j in 1:length(needcols)) {
	  needrow<-needrow & as.character(dt[,needcols[j]])==thecon[i,needcols[j]]
	}
	tmp<-dt[needrow,]
	vaf<-log10(tmp[,thecon[i,"M"]]/(0.00001+tmp[,"N"]))
	names(vaf)<-row.names(tmp)
	isFG<-rep(0,nrow(tmp))
	isFG[row.names(tmp) %in% row.names(marker)[marker[,"Mut"]==thecon[i,"M"]]]<-1	
	FG<-vaf[isFG==1]
	BG<-vaf[isFG==0]
	histt<-count_bins(vec=BG, minu=vaf_min_log, maxu=vaf_Max_log, nbin=bins, zero_label=-6)
	
	plot_bars(histt,yy=yyy)	
	txt<-paste(c(thecon[i,"Forward"], " (",length(BG),")"),collapse="")
	text(label.x,yyy,txt,cex=cex.label,pos=4)
	med<-sprintf("%.1f",median(BG))
	text(zero_label,yyy+median_offset,med,cex=cex.label,pos=4)
	if(length(FG)>0) {
	  for(j in 1:length(FG)) {
	    rrrr<-rnorm(1,mean=0,sd=0.05)
		if(rrrr>0.2) rrrr<-0.2
		if(rrrr<0-0.2) rrrr<-0-0.2
		coll<-""
		if(marker[names(FG)[j],"MutAllele"] %in% c("4v4","BRAF.V600E")) coll<-ladder.cols[3]
		if(marker[names(FG)[j],"MutAllele"] %in% c("2v4")) coll<-ladder.cols[2]
		if(marker[names(FG)[j],"MutAllele"] %in% c("1v4","1v2")) coll<-ladder.cols[1]
	    points(FG[j], yyy+rrrr,cex=cex.points,pch=16,col=coll)
	  }
	}
  }
}





plot_one_flank1<-function(ifn,minCvg=200000,markerfn="markers.txt",vaf_min_log=-5, vaf_Max_log=-1, bins=40, zero_label=-6,cex.label=1,cex.points=1,ladder.cols=c("red","blue","black"),ladder.vals=c(0.0005, 0.001,0.002),main) {
  flank<-1  
  dt<-read.table(ifn,header=TRUE,sep="\t")
  colnames(dt)[colnames(dt)=="geno"]<-"R"
  dt[dt[,"Chr"]=="chr1" & as.integer(dt[,"Pos"])>153391708 & as.integer(dt[,"Pos"])<153391855,"Mappability"]<-1
  dt<-dt[dt[,"Mappability"]==1 & 
         as.character(dt[,"R"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"N1"]) %in% c("A","C","G","T") & 
		 as.character(dt[,"P1"]) %in% c("A","C","G","T"),]
  row.names(dt)<-apply(cbind(as.character(dt[,"Chr"]),as.character(dt[,"Pos"])),1,paste,collapse=".")  
  if(!is.na(markerfn)) {
    marker<-read.table(markerfn,header=TRUE,sep="\t",colClass="character")
	row.names(marker)<-apply(marker[,c("Chr","Pos")],1,paste,collapse=".")
  }
  isSomatic<-1*(row.names(dt) %in% row.names(marker))
  dt<-cbind(dt,isSomatic)
  dt<-dt[dt[,"N"]>minCvg | dt[,"isSomatic"]==1,]  
  thecon<-make_context(Lk=flank,Rk=flank)
  needcols<-setdiff(colnames(thecon),c("M","rR","rM","Forward","Reverse","rN1","rP1"))
  bases<-c("A","C","G","T")
  for(i in 1:length(bases)) {
    for(j in 1:length(bases)) {
	  if(j!=i) {
	    reff<-bases[i]
	    mutt<-bases[j]
		needed.context<-thecon[thecon[,"R"]==reff & thecon[,"M"]==mutt,]
		
		plot(-100,xlim=c(zero_label-0.5,0+0.5),ylim=c(-0.1,nrow(needed.context)+1),xlab="",ylab="",xaxt="n",yaxt="n",bty="n",main="")
		text(zero_label*0.5,nrow(needed.context)+0.5,main,cex=1)
        for(ll in 2:6) {
          lines(c(-ll,-ll),c(0,nrow(needed.context)-1),col="#EEEEEE",lwd=0.5)
        }
		for(ll in 1:nrow(needed.context)) {
		  yyy<-nrow(needed.context)-ll
		  lines(c(zero_label,vaf_Max_log),c(yyy,yyy),lwd=0.5,col="#DDDDDD")
		}
        axis(1,at=c(-c(6:2)),labels=c("-6","-5","-4","-3","-2"),cex.axis=cex.label)        
        for(ll in 1:length(ladder.vals)) {
          lines(c(log10(ladder.vals[ll]),log10(ladder.vals[ll])),c(-0.4,nrow(needed.context)-0.4),col=ladder.cols[ll])
        }
		
		for(k in 1:nrow(needed.context)) {
		  yyy<-nrow(needed.context)-k
		  needrow<-rep(TRUE,nrow(dt))
		  for(m in 1:length(needcols)) {
	        needrow<-needrow & as.character(dt[,needcols[m]])==needed.context[k,needcols[m]]
	      }
		  tmp<-dt[needrow,]
		  vaf<-log10(tmp[,needed.context[k,"M"]]/(0.00001+tmp[,"N"]))
		  names(vaf)<-row.names(tmp)
		  isFG<-rep(0,nrow(tmp))
		  isFG[row.names(tmp) %in% row.names(marker)[marker[,"Mut"]==needed.context[k,"M"]]]<-1	
		  FG<-vaf[isFG==1]
		  BG<-vaf[isFG==0]
		  histt<-count_bins(vec=BG, minu=vaf_min_log, maxu=vaf_Max_log, nbin=bins, zero_label=-6)		  
	      plot_bars(histt,yy=yyy)	
	      txt<-paste(c(needed.context[k,"Forward"], " (",length(BG),")"),collapse="")	
	      text(label.x,yyy,txt,cex=cex.label,pos=4)
	      med<-sprintf("%.1f",median(BG))
	      text(zero_label,yyy+median_offset,med,cex=cex.label,pos=4)
	      if(length(FG)>0) {
	        for(n in 1:length(FG)) {
	          rrrr<-rnorm(1,mean=0,sd=0.05)
		      if(rrrr>0.2) rrrr<-0.2
		      if(rrrr<0-0.2) rrrr<-0-0.2
		      coll<-""
		      if(marker[names(FG)[n],"MutAllele"] %in% c("4v4","BRAF.V600E")) coll<-ladder.cols[3]
		      if(marker[names(FG)[n],"MutAllele"] %in% c("2v4")) coll<-ladder.cols[2]
		      if(marker[names(FG)[n],"MutAllele"] %in% c("1v4","1v2")) coll<-ladder.cols[1]
	          points(FG[n], yyy+rrrr,cex=cex.points,pch=16,col=coll)
			}
	      }
		}
	  }
	}  
  }  
}
do_errrate<-function(ifn) {
  dt<-read.table(ifn,header=FALSE,sep="\t",skip=101,row.names=1)
  l30.before<-100*sum(as.numeric(dt[as.character(0:29),1]))/sum(as.numeric(dt[as.character(0:100),1]))
  l30.after<-100*sum(as.numeric(dt[as.character(0:29),2]))/sum(as.numeric(dt[as.character(0:100),2]))
  plot(-100,xlim=c(0.5,2.5),ylim=c(-0.5,8),xaxt="n",xlab="",las=2,ylab="% low quality bases (Phred<30)",bty="n",cex.lab=cex.text,cex.axis=cex.text)
  xleft<-0.7
  xright<-1.3
  ytop<-l30.before
  ybottom<-0
  rect(xleft=xleft,xright=xright,ytop=ytop,ybottom=ybottom,col="tomato",border=NA)
  text(1,ytop+0.2,sprintf("%.1f%%",ytop),cex=cex.text)
  text(1,-0.5,"Raw",cex=cex.text)
  xleft<-1.7
  xright<-2.3
  ytop<-l30.after
  ybottom<-0
  rect(xleft=xleft,xright=xright,ytop=ytop,ybottom=ybottom,col="tomato",border=NA)
  text(2,-0.5,"no LQReads",cex=cex.text)
  text(2,ytop+0.2,sprintf("%.1f%%",ytop),cex=cex.text)
}



cex.text<-0.9
cex.points<-0.9
cex.label<-0.9
flank<-0

vaf_Max_log<-0-2
vaf_min_log<-0-6
zero_label<-0-6
bins<-40


ladder.cols<-c("red","blue","black")

plot_1flank<-function(marker, ifn, minCvg,pdfpng="pdf") {
  markerfn<-marker
  if(pdfpng=="pdf") {
    ofn<-paste(c("pdf.",ifn,"_1flank.pdf"),collapse="")
    pdf(ofn,width=7,height=7,useDingbats=FALSE)
  } else {
    ofn<-paste(c("png.",ifn,"_1flank.png"),collapse="")
    png(ofn,width=1000,height=1000)
  }
  par(mai=c(0.3,0.1,0.1,0.1))
  ladder.vals<-c(0.0005, 0.001,0.002)
  if(length(grep("2to10000",ifn,value=TRUE))==1) {     ladder.vals<-c(0.0001, 0.0002,0.0004)   }
  main<-gsub("cpg.mapp.geno_|.counts.|_L001.bam.txt","",ifn)
  plot_one_flank0(ifn,minCvg,flank,markerfn,vaf_min_log, vaf_Max_log, bins, zero_label,cex.label,cex.points,ladder.cols,ladder.vals,main=main)
  text(-3,13,minCvg,cex=cex.text)
  dev.off()
}

args<-commandArgs(trailingOnly=TRUE)
if(!(length(args) %in% c(3,4))) {
  print("Usage: Rscript ~ <marker.ifn> <ifn> <minCvg | 100000; 10000> | <pdf/png>")
} else {
  if(length(args)==3) {
    plot_1flank(args[1], args[2], as.integer(args[3]))
  } 
  if(length(args)==4) {
    plot_1flank(args[1], args[2], as.integer(args[3]),pdfpng="png")
  }
}




