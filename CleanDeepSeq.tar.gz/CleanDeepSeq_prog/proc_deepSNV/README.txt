

This is a standalone package to run deepSNV.
This package assumes avaliability of allele counts from tumor and normal, respectively.

You will need to install deepSNV per instruction from https://bioconductor.org/packages/release/bioc/html/deepSNV.html

We have tested deepSNV on R 3.5.0.

