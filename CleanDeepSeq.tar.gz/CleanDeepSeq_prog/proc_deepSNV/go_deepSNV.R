# tested on R 3.5.0
# see https://bioconductor.org/packages/release/bioc/html/deepSNV.html

library(deepSNV)

source("test_with_deepSNV.R")
tumifn<-"cpg.mapp.geno_Q30.counts.Colo829_TtoN_1to1000_Rep1_S1_L001.bam.txt"
nomifn<-"cpg.mapp.geno_Q30.counts.Colo829Normal_S5_L001.bam.txt"
ofn<-"test_1v1000.txt"
regionifn<-"markers.txt"
do.one.pair(tumifn,nomifn,ofn,regionifn)
dta<-read.table(ofn,header=TRUE,sep="\t")
ofnpdf<-paste(c("pdf.",ofn,".pdf"),collapse="")
pdf(ofnpdf)
fp<-plot_mas(dta,pref=" by CleanDeepSeq")
dev.off()
