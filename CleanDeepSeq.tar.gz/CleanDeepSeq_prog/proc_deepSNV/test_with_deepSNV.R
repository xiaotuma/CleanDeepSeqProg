make_matr<-function(tumifn, nomifn,regionifn) {
  regions<-read.table(regionifn,header=TRUE)  
  tum<-read.table(tumifn,header=TRUE,sep="\t")
  row.names(tum)<-apply(cbind(as.character(tum[,1]),as.character(tum[,2])),1,paste,collapse=".")
  nom<-read.table(nomifn,header=TRUE,sep="\t")
  row.names(nom)<-apply(cbind(as.character(nom[,1]),as.character(nom[,2])),1,paste,collapse=".")
  tum.in.region<-rep(FALSE,nrow(tum))
  for(i in 1:nrow(regions)) {
    tum.in.region[as.character(tum[,"Chr"])==as.character(regions[i,"Chr"]) & abs(tum[,"Pos"]-regions[i,"Pos"])<1000]<-TRUE
  }
  tum<-tum[tum.in.region,]

  nom.in.region<-rep(FALSE,nrow(nom))
  for(i in 1:nrow(regions)) {
    nom.in.region[as.character(nom[,"Chr"])==as.character(regions[i,"Chr"]) & abs(nom[,"Pos"]-regions[i,"Pos"])<1000]<-TRUE
  }
  nom<-nom[nom.in.region,]  
  
  tum<-tum[tum[,"N"]>10000,]
  nom<-nom[nom[,"N"]>1000,]
  common<-intersect(row.names(tum),row.names(nom))
  tum<-tum[common,]
  nom<-nom[common,]
  tumFwd<-cbind(ceiling(tum[,c("A","T","C","G")]*0.5),0)
  tumRvs<-cbind(ceiling(tum[,c("A","T","C","G")]*0.5),0)
  tumU<-cbind(tumFwd,tumRvs)
  colnames(tumU)<-c("A","T","C","G","-","a","t","c","g","_")

  nomFwd<-cbind(ceiling(nom[,c("A","T","C","G")]*0.5),0)
  nomRvs<-cbind(ceiling(nom[,c("A","T","C","G")]*0.5),0)
  nomU<-cbind(nomFwd,nomRvs)
  colnames(nomU)<-c("A","T","C","G","-","a","t","c","g","_")
  return(list(tum=tumU,nom=nomU,tumO=tum[,c("A","T","C","G")],nomO=nom[,c("A","T","C","G")]))
}

do.one.pair<-function(tumifn,nomifn,ofn,regionifn) {
  mat<-make_matr(tumifn, nomifn,regionifn)
  test<-as.matrix(mat$tum)
  controls<-as.matrix(mat$nom)

  kk<-deepSNV(test,controls, alternative = "greater", dirichlet.prior = NULL, pseudo.count=1, combine.method = "fisher", over.dispersion = 100, model = "bin")
  rlt<-cbind(mat$tumO, mat$nomO)
  colnames(rlt)<-c(paste("D.",colnames(mat$tumO),sep=""),paste("N.",colnames(mat$nomO),sep=""))
  pv<-p.val(kk)
  colnames(pv)<-paste("Pvalue.",colnames(test)[1:5],sep="")
  final<-cbind(rlt, pv[,1:4])
  Mut<-rep("",nrow(final))
  Alleles<-rep("",nrow(final))
  regions<-read.table(regionifn,header=TRUE)
  for(i in 1:nrow(regions)) {
    idx<-paste(as.character(regions[i,1]),as.character(regions[i,2]),sep=".")
    if(idx %in% row.names(final)) {
      Mut[row.names(final) == idx]<-as.character(regions[i,4])
      Alleles[row.names(final) == idx]<-as.character(regions[i,5])
    }
  }
  ret<-cbind(Chr.Pos=row.names(final),final,Mut,Alleles)
  write.table(ret,ofn,row.names=F,col.names=TRUE,sep="\t",quote=F)
}
plot_mas<-function(dta,pref) {
  pcut<-0.05
  colA<-"black"
  colC<-"black"
  colG<-"black"
  colT<-"black"
  theN.tum<-dta[,"D.A"]+dta[,"D.C"]+dta[,"D.G"]+dta[,"D.T"]
  theN.nom<-dta[,"N.A"]+dta[,"N.C"]+dta[,"N.G"]+dta[,"N.T"]
  dta[is.na(dta[,"Pvalue.A"]),"Pvalue.A"]<-999
  dta[is.na(dta[,"Pvalue.C"]),"Pvalue.C"]<-999
  dta[is.na(dta[,"Pvalue.G"]),"Pvalue.G"]<-999
  dta[is.na(dta[,"Pvalue.T"]),"Pvalue.T"]<-999
  fA.tum<-dta[,"D.A"]/theN.tum
  fC.tum<-dta[,"D.C"]/theN.tum
  fG.tum<-dta[,"D.G"]/theN.tum
  fT.tum<-dta[,"D.T"]/theN.tum
  
  fA.nom<-dta[,"N.A"]/theN.nom
  fC.nom<-dta[,"N.C"]/theN.nom
  fG.nom<-dta[,"N.G"]/theN.nom
  fT.nom<-dta[,"N.T"]/theN.nom
  
  uuuu<-NULL
  
  
  plot(100,xlim=c(1e-7,1e-1),ylim=c(1e-7,1e-1),log="xy",main=paste(c("Filtering", pref),collapse=" "),xlab="Freuqency in Normal",ylab="Frequency in Dilution",las=1)
  use<- fA.nom<0.01 & as.character(dta[,"Mut"])=="" & dta[,"Pvalue.A"]>=pcut/(nrow(dta)*4)  
  points(fA.nom[use],fA.tum[use],cex=0.5,col="gray",pch=16)
  use<- fC.nom<0.01 & as.character(dta[,"Mut"])=="" & dta[,"Pvalue.C"]>=pcut/(nrow(dta)*4)  
  points(fC.nom[use],fC.tum[use],cex=0.5,col="gray",pch=16)
  use<- fG.nom<0.01 & as.character(dta[,"Mut"])=="" & dta[,"Pvalue.G"]>=pcut/(nrow(dta)*4)  
  points(fG.nom[use],fG.tum[use],cex=0.5,col="gray",pch=16)
  use<- fT.nom<0.01 & as.character(dta[,"Mut"])=="" & dta[,"Pvalue.T"]>=pcut/(nrow(dta)*4)  
  points(fT.nom[use],fT.tum[use],cex=0.5,col="gray",pch=16)
  
  nFP<-0  
  theFP<-NULL
  use<- which(fA.nom<0.01 & as.character(dta[,"Mut"])!="A" & dta[,"Pvalue.A"]<pcut/(nrow(dta)*4))
  theFP<-rbind(theFP,dta[use,])
  nFP<-nFP + length(use)
  if(length(use)>0) for(i in 1:length(use)) {
    fnom<-fA.nom[use[i]]
	ftum<-fA.tum[use[i]]
	if(fnom<1e-6) fnom<-1e-6
	pa<-dta[use[i],"Pvalue.A"]
	cex<-0.5
	if(pa<1e-10) cex<-0.5
	if(pa<1e-30) cex<-0.9
	if(pa<1e-50) cex<-1.3
	if(pa<1e-70) cex<-1.7
	points(fnom,ftum,col=colA,cex=cex,pch=16)
	uuuu<-rbind(uuuu,dta[use[i],])
  }
  use<- which(fC.nom<0.01 & as.character(dta[,"Mut"])!="C" & dta[,"Pvalue.C"]<pcut/(nrow(dta)*4))
  theFP<-rbind(theFP,dta[use,])
  nFP<-nFP + length(use)
  if(length(use)>0) for(i in 1:length(use)) {
    fnom<-fC.nom[use[i]]
	ftum<-fC.tum[use[i]]
	if(fnom<1e-6) fnom<-1e-6
	pa<-dta[use[i],"Pvalue.C"]
	cex<-0.5
	if(pa<1e-10) cex<-0.5
	if(pa<1e-30) cex<-0.9
	if(pa<1e-50) cex<-1.3
	if(pa<1e-70) cex<-1.7
	points(fnom,ftum,col=colC,cex=cex,pch=16)
	uuuu<-rbind(uuuu,dta[use[i],])
  }
  use<- which(fG.nom<0.01 & as.character(dta[,"Mut"])!="G" & dta[,"Pvalue.G"]<pcut/(nrow(dta)*4))
  theFP<-rbind(theFP,dta[use,])
  nFP<-nFP + length(use)
  if(length(use)>0)   for(i in 1:length(use)) {
    fnom<-fG.nom[use[i]]
	ftum<-fG.tum[use[i]]
	if(fnom<1e-6) fnom<-1e-6
	pa<-dta[use[i],"Pvalue.G"]
	cex<-0.5
	if(pa<1e-10) cex<-0.5
	if(pa<1e-30) cex<-0.9
	if(pa<1e-50) cex<-1.3
	if(pa<1e-70) cex<-1.7
	points(fnom,ftum,col=colG,cex=cex,pch=16)
	uuuu<-rbind(uuuu,dta[use[i],])
  }
  use<- which(fT.nom<0.01 & as.character(dta[,"Mut"])!="T" & dta[,"Pvalue.T"]<pcut/(nrow(dta)*4))
  theFP<-rbind(theFP,dta[use,])
  nFP<-nFP + length(use)
  if(length(use)>0) for(i in 1:length(use)) {
    fnom<-fT.nom[use[i]]
	ftum<-fT.tum[use[i]]
	if(fnom<1e-6) fnom<-1e-6
	pa<-dta[use[i],"Pvalue.T"]
	cex<-0.5
	if(pa<1e-10) cex<-0.5
	if(pa<1e-30) cex<-0.9
	if(pa<1e-50) cex<-1.3
	if(pa<1e-70) cex<-1.7
	points(fnom,ftum,col=colT,cex=cex,pch=16)
	uuuu<-rbind(uuuu,dta[use[i],])
  }


  
  use<- which(as.character(dta[,"Mut"])!="")
  nFN<-0
  if(length(use)>0) for(i in 1:length(use)) {
    mut<-as.character(dta[use[i],"Mut"])
	if(mut=="A") { ftum<-fA.tum[use[i]]; fnom<-fA.nom[use[i]]; }
	if(mut=="C") { ftum<-fC.tum[use[i]]; fnom<-fC.nom[use[i]]; }
	if(mut=="G") { ftum<-fG.tum[use[i]]; fnom<-fG.nom[use[i]]; }
	if(mut=="T") { ftum<-fT.tum[use[i]]; fnom<-fT.nom[use[i]]; }
	pa<-dta[use[i],paste("Pvalue.",mut,sep="")]
	if(pa>=pcut/(nrow(dta)*4)) {
	  nFN<-nFN+1
	}
	cex<-0.5
	if(pa<1e-10) cex<-0.5
	if(pa<1e-30) cex<-0.9
	if(pa<1e-50) cex<-1.3
	if(pa<1e-70) cex<-1.7
	cols<-colA
	if(mut=="C") cols<-colC
	if(mut=="G") cols<-colG
	if(mut=="T") cols<-colT
	if(pa>=pcut/(nrow(dta)*4)) {
	  points(fnom,ftum,col="red",cex=0.9,pch=1)
	} else {
	  points(fnom,ftum,col="red",cex=cex,pch=16)
	}

  }
  text(1e-4,1e-1,paste(c("FN: ",nFN, "/", length(use),"  FP: ",nFP),collapse=""))
  legend(1e-2,1e-4,pch=c(1,16,16,16),col=c("red","red","black","gray"),cex=0.9,legend=c("known somatic; FDR>=0.01","known somatic; FDR<0.01","false positive","insignificant"),border=NA,bty="n")  
  points(1e-7,1e-5,pch=16,cex=0.5); text(2e-7,1e-5, "10");
  points(1e-7,1e-4,pch=16,cex=0.9); text(2e-7,1e-4, "30");
  points(1e-7,1e-3,pch=16,cex=1.3); text(2e-7,1e-3, "50");
  points(1e-7,1e-2,pch=16,cex=1.7); text(2e-7,1e-2, "70");
  return(theFP)
}




args<-commandArgs(trailingOnly=TRUE)
if(length(args)==4) {
  library(deepSNV)
  tumifn<-args[1]
  nomifn<-args[2]
  ofn<-args[3]
  regionifn<-args[4] # "markers.txt"
  do.one.pair(tumifn,nomifn,ofn,regionifn)
  dta<-read.table(ofn,header=TRUE,sep="\t")
  ofnpdf<-paste(c("pdf.",ofn,".pdf"),collapse="")
  pdf(ofnpdf)
  plot_mas(dta,pref=" by CleanDeepSeq")
  dev.off()
  
} else {
  print("Rscript ~ <tumor count file> <normal count file> <output file> <region definition>")
  print("Need package deepSNV")
  print("see https://bioconductor.org/packages/release/bioc/html/deepSNV.html")
  print("tested on R 3.5.0")
}

