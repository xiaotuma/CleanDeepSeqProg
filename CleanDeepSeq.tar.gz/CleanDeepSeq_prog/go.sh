sh ./code/countbam_slim.sh ./bamdir/Colo829Normal_S5_L001.bam 100000 
sh ./code/countbam_slim.sh ./bamdir/Colo829_TtoN_1to1000_Rep1_S1_L001.bam 500000

